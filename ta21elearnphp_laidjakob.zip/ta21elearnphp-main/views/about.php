<?php include __DIR__ . '/partials/header.php' ?>
    <h1>About us</h1>
<?php include __DIR__ . '/partials/footer.php' ?>