<?php include __DIR__ . '/partials/header.php' ?>
    <img src="https://http.cat/404">
<?php include __DIR__ . '/partials/footer.php' ?>