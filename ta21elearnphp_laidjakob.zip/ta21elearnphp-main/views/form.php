<?php include __DIR__ . '/partials/header.php' ?>
    <form method="POST" action="/form?color=red&flower=rose">
        <input type="text" placeholder="Name" name="name">
        <input type="number" placeholder="Age" name="age">
        <input type="submit">
    </form>
<?php include __DIR__ . '/partials/footer.php' ?>